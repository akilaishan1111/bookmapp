
import velox.api.layer1.annotations.*;
import velox.api.layer1.common.Log;
import velox.api.layer1.data.*;
import velox.api.layer1.simplified.*;

import javax.swing.*;
import java.awt.*;
import java.util.*;

@Layer1SimpleAttachable
@Layer1StrategyName("Absorption & Imbalance Detector")
@Layer1ApiVersion(Layer1ApiVersionValue.VERSION1)
public class AbsorptionImbalanceIndicator implements CustomModule, Layer1SimpleTradeListener, Layer1SimpleInstrumentListener {

    private CustomModuleContext context;
    private String currentInstrument = "";
    private double buyVolume = 0;
    private double sellVolume = 0;
    private double imbalanceThreshold = 0.7; // 70% imbalance
    private double absorptionThreshold = 50; // 50 contracts absorbed

    @Override
    public void initialize(String alias, CustomModuleContext context) {
        this.context = context;
        Log.info("AbsorptionImbalanceIndicator initialized.");
    }

    @Override
    public void stop() {
        Log.info("AbsorptionImbalanceIndicator stopped.");
    }

    @Override
    public void onInstrumentAdded(String instrumentAlias) {
        if (instrumentAlias.contains("GC") || instrumentAlias.contains("6E")) {
            currentInstrument = instrumentAlias;
            Log.info("Monitoring instrument: " + currentInstrument);
        }
    }

    @Override
    public void onDepthSnapshot(DepthSnapshot depthSnapshot) {
        if (!depthSnapshot.alias.equals(currentInstrument)) return;

        Optional<DepthLevel> bestBid = depthSnapshot.bidLevels.stream().findFirst();
        Optional<DepthLevel> bestAsk = depthSnapshot.askLevels.stream().findFirst();

        if (bestBid.isPresent() && bestAsk.isPresent()) {
            double bidSize = bestBid.get().size;
            double askSize = bestAsk.get().size;
            double total = bidSize + askSize;

            if (total == 0) return;

            double bidRatio = bidSize / total;
            double askRatio = askSize / total;

            if (bidRatio > imbalanceThreshold) {
                showAlert("Buy Imbalance Detected: " + (int)(bidRatio * 100) + "%", Color.GREEN);
            } else if (askRatio > imbalanceThreshold) {
                showAlert("Sell Imbalance Detected: " + (int)(askRatio * 100) + "%", Color.RED);
            }
        }
    }

    @Override
    public void onTrade(TradeInfo tradeInfo) {
        if (!tradeInfo.alias.equals(currentInstrument)) return;

        if (tradeInfo.isBidAggressor) {
            buyVolume += tradeInfo.size;
        } else {
            sellVolume += tradeInfo.size;
        }

        if (buyVolume > absorptionThreshold) {
            showAlert("Absorption Detected: Market Buys Absorbed", Color.BLUE);
            buyVolume = 0;
        }
        if (sellVolume > absorptionThreshold) {
            showAlert("Absorption Detected: Market Sells Absorbed", Color.ORANGE);
            sellVolume = 0;
        }
    }

    private void showAlert(String message, Color color) {
        Log.info(message);
        SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(null, message, "Order Flow Signal", JOptionPane.INFORMATION_MESSAGE));
    }
}
